package com.virtua.launcher.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.virtua.launcher.R
import com.virtua.launcher.VirtuaApp
import com.virtua.launcher.capture.CaptureService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground service that draws a small HUD overlay on top of whatever app is
 * in front (e.g. a game), showing a periodically-refreshed FSRCNN-upscaled
 * crop of the last captured frame, plus a Stop button.
 *
 * Honest limits, stated plainly since this is the piece that answers "does
 * this actually change what I see on screen":
 *  - This window is drawn ON TOP of whatever is in front. It does not, and
 *    on stock non-root Android cannot, modify the game's own rendering
 *    underneath -- there is no public API for that without root, an OEM
 *    hook, or a SurfaceFlinger-level trick. See CaptureService's class doc
 *    for the same point from the capture side.
 *  - It refreshes every REFRESH_MS, not every game frame. This device has
 *    no NPU; TFLite inference (even GPU-delegate-accelerated) on a budget
 *    SoC is realistically tens of ms per net. This is a periodic "enhanced
 *    snapshot" HUD, not a frame-accurate real-time filter -- true 30-60fps
 *    replacement isn't realistic on this hardware.
 *  - Only FSRCNN runs here (not depth/motion too) to keep each cycle as
 *    light as this hardware can manage; depth/motion still run on-demand
 *    from MainActivity's "Apply pipeline" button.
 *
 * Requires CaptureService to already be running (Start Capture first) --
 * otherwise there's no frame to process and the HUD just shows a waiting
 * message rather than doing nothing silently.
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            startForeground(NOTIFICATION_ID, buildNotification())
            addOverlay()
            startLoop()
        } catch (e: Exception) {
            // Some OEMs (MIUI in particular) have their own separate
            // "display over other apps while in background" permission on
            // top of the standard SYSTEM_ALERT_WINDOW grant -- addOverlay()
            // can throw even when Settings.canDrawOverlays() reported true.
            // Fail loudly with a visible message instead of silently dying.
            Toast.makeText(
                this,
                "Overlay failed to start: ${e.javaClass.simpleName}: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun addOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_hud, null)
        view.findViewById<View>(R.id.btnOverlayStop).setOnClickListener { stopSelf() }

        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            // NOT_FOCUSABLE only -- deliberately no FLAG_NOT_TOUCHABLE, or the
            // Stop button underneath this view's own bounds would be unclickable.
            // The overlay is small and docked to a corner, so it only intercepts
            // touches inside its own bounds; the game underneath is untouched
            // everywhere else -- the standard "chat heads" overlay pattern.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 100
        }

        wm.addView(view, params)
        overlayView = view
    }

    private fun startLoop() {
        val app = VirtuaApp.instance
        scope.launch {
            while (true) {
                val frame = CaptureService.latest()
                val fsrcnnOn = app.featureRegistry.get("fsrcnn")?.enabled == true
                        && app.superResEstimator.isModelAvailable()

                if (frame != null && fsrcnnOn) {
                    val t0 = System.nanoTime()
                    val up = app.superResEstimator.upscale(frame, PREVIEW_INPUT_SIZE)
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    if (up != null) {
                        val gpuTag = if (app.superResEstimator.isUsingGpu()) "gpu" else "cpu"
                        withContext(Dispatchers.Main) {
                            overlayView?.findViewById<ImageView>(R.id.imgOverlayPreview)
                                ?.setImageBitmap(up)
                            overlayView?.findViewById<TextView>(R.id.txtOverlayLatency)?.text =
                                "fsrcnn $gpuTag ${up.width}x${up.height} (${ms}ms)"
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        overlayView?.findViewById<TextView>(R.id.txtOverlayLatency)?.text =
                            if (frame == null) "waiting for capture…" else "fsrcnn disabled/unavailable"
                    }
                }
                delay(REFRESH_MS)
            }
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Virtua overlay", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Virtua Launcher")
            .setContentText("Overlay HUD running — tap Stop in the HUD, or here, to end")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        overlayView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: IllegalArgumentException) {
                // View was already detached (e.g. addView never fully completed) -- ignore.
            }
        }
        overlayView = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "virtua_overlay"
        private const val NOTIFICATION_ID = 43
        private const val REFRESH_MS = 500L
        private const val PREVIEW_INPUT_SIZE = 64
    }
}
