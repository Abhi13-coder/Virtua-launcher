package com.virtua.launcher.overlay

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Wraps the SYSTEM_ALERT_WINDOW permission flow (Settings.ACTION_MANAGE_OVERLAY_PERMISSION
 * -- there's no ActivityResultContract for this one, unlike MediaProjection, so this
 * launches the settings screen directly and re-checks Settings.canDrawOverlays() on
 * return) plus OverlayService start/stop. Must be constructed in onCreate, before
 * STARTED, same requirement as CaptureManager.
 */
class OverlayManager(private val activity: AppCompatActivity) {

    var onDenied: (() -> Unit)? = null
    var onGranted: (() -> Unit)? = null

    private val launcher: ActivityResultLauncher<Intent> =
        activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(activity)) {
                startService()
                onGranted?.invoke()
            } else {
                onDenied?.invoke()
            }
        }

    fun requestOverlay() {
        if (Settings.canDrawOverlays(activity)) {
            startService()
            onGranted?.invoke()
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${activity.packageName}")
        )
        launcher.launch(intent)
    }

    private fun startService() {
        ContextCompat.startForegroundService(activity, Intent(activity, OverlayService::class.java))
    }

    fun stopOverlay() {
        activity.stopService(Intent(activity, OverlayService::class.java))
    }
}
